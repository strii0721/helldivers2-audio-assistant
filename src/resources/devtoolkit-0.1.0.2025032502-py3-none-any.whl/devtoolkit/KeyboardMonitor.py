import threading
import keyboard
import time

class KeyboardMonitor:
    LOOP_INTERVAL = 0.001
    def __init__(self):
        self.alive = False
        self.signal = threading.Event()
        self.key_name = None
        self.daemon = None
        
    def start(self):
        self.alive = True
        return self
    
    def stop(self):
        self.alive = False
        
    def is_alive(self):
        return self.alive

    def listen_daemon(self):
        while True:
            keyboard_event = keyboard.read_event() 
            if keyboard_event.event_type == keyboard.KEY_DOWN:
                self.key_name = keyboard_event.name
                self.signal.set()
            if not self.alive: break
            
    def listen(self):
        if self.signal.is_set():
            self.signal.clear()
            tmp = self.key_name
            self.key_name = None
            return tmp
        else:
            return None
        
    def wait_for(self,
                 *args):
        while True:
            key = self.listen()
            if key is not None and (key in args or not args): return key
            time.sleep(self.LOOP_INTERVAL)